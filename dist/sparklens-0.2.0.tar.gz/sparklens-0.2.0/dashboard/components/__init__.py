"""Reusable Streamlit presentation components."""
