"""Shared dashboard styling."""
